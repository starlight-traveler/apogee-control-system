//
// Copyright (c) 2023 alandefreitas (alandefreitas@gmail.com)
//
// Distributed under the Boost Software License, Version 1.0.
// https://www.boost.org/LICENSE_1_0.txt
//

#ifndef MATPLOT_DETAIL_CONFIG_H
#define MATPLOT_DETAIL_CONFIG_H

#include <matplot/detail/exports.h>

#endif //MATPLOT_DETAIL_CONFIG_H
