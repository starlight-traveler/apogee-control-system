---
name: Improvement Proposal
about: For formal improvement proposals. For discussing new ideas, please use "Matplot++ Ideas 💡" link below.
title: ''
labels: 
assignees: ''

---

**Feature category**
- [ ] *enhancement - build system*
- [ ] *enhancement - backends*
- [ ] *enhancement - build system*
- [ ] *enhancement - documentation*
- [ ] *enhancement - plot categories*

**The problem**
<!--Please be civil. This is an environment for collaboration.-->

**The solution I'd like**

**Alternatives I've considered**

**Additional context**
<!--optional-->
