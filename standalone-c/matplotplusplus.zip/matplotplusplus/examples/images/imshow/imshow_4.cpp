#include <matplot/matplot.h>

int main() {
    using namespace matplot;
    imshow("lena_color.tiff");

    show();
    return 0;
}